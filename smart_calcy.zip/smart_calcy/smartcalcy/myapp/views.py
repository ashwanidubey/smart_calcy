from django.shortcuts import render
from django.http import HttpResponse
from datetime import date,time,datetime
Date=date.today()
#Time=datetime.now().time()
Time=time()
Day=datetime.today().strftime('%A')
import matplotlib.pyplot as plt
# Create your views here.
a=[]
decide=0
def rem2(x,z):##for and,from
    print('rem2')
    s=""
    if x.endswith("is") :
        x=x[0:-2]
    x=x.split(z)
    print(x)
    if z=='from' :
        x=x[::-1]
    for x1 in x :
        s=s+','+x1
    return s
def rem1(x,z):##for sum,of,sub,subtract
    x=x.split(z)
    x=x[1]
    print('rem1',x)
    if '?' in x :
        x=x[0:-1]
    if x.endswith("is") :
        x=x[0:-2]
    if 'of' in x:
       x=rem1(x,'of')
    if 'by' in x and "multipl" in z:
       x=rem1(x,'by')
    if 'and' in x:
        x=rem2(x,'and')
    if 'from' in x:
        x=rem2(x,'from')
    print(x,"over rem1")
    return x
def rem(x,y=','): ##for comma and space
    print('rem')
    x=x.split(',')
    s=""
    for x1 in x :
        s=s+' '+x1
    return x
def change(x):
     print('change')
     for x1 in x:
       if x1!='' and x1!=' 'and x1!='   ':
                   try :
                        a.append(eval(x1))
                   except :
                       decide=1
def add(x):
    print("add")
    sum=0
    if "summation" in x:
           z="summation"
           print(z)
           x=rem1(x,z)
           x=rem(x)##b.append(rem(x))
    elif "sum" in x:
           z="sum"
           print(z)
           x=rem1(x,z)
           x=rem(x)
    elif "addition" in x:
           z="addition"
           print(z)
           x=rem1(x,z)
           x=rem(x)
    elif "add" in x:
           z="add"
           print(z)
           x=rem1(x,z)
           x=rem(x)
    elif "plus" in x:
            print('plus')
            x=rem2(x,'plus')
            x=rem(x)
    change(x)
    print(a)
    for x1 in a:
         sum=sum+x1
    return sum
def multiply(x):
    into=1
    print("multiply")
    if "multiplication" in x:
           print(multiply)
           z="multiplication"
           x=rem1(x,z)
           x=rem(x)##b.append(rem(x))
    elif "product" in x:
           z="product"
           print(z)
           x=rem1(x,z)
           x=rem(x)##b.append(rem(x))
    elif "multiplied" in x:
           z="multiplied"
           print(z)
           x=rem1(x,z)
           x=rem(x)
    elif "multiply" in x:
           z="multiply"
           print(z)
           x=rem1(x,z)
           x=rem(x)
    elif "into" in x:
            x=rem2(x,'into')
            print('into')
            x=rem(x)
    change(x)
    print(a)
    for x1 in a:
        into=into*x1
    return into
def divide(x):
    print("divide")
    if "divided" in x:
        print("divided")
        x=rem2(x,'divided')
    elif  "divide" in x:
        print("divide")
        x=rem1(x,'divide ')
    if "by" in x:
            print("by")
            x=rem2(x,'by')
            x=rem(x)
    change(x)
    print(a)
    if len(a)<2:
        return error
    else :
        result=a[0]**2
        for x in a:
            result=result/x
    return result
def minus(x):
    print("minus")
    if "minus" in x:
         print("minus")
         x=rem2(x,'minus')
         x=rem(x)
    if "subtract" in x:
        print("subtract")
        x=rem1(x,"subtract")
        x=rem(x)
    if "sub" in x:
        print('sub')
        x=rem1(x,"sub")
        x=rem(x)
    change(x)
    print(a )
    res=2*a[0]
    for x1 in a :
        res=res-x1
    return res
def home1(request):

    x=[1,2,3,4]
    y=[3,4,5,6]
    test=plt.plot(x,y)
    data={}
    i=str(Time).split(':')
    x=(eval(i[0]))+(eval(i[1])/100)+(eval(i[2])/10000)
    if 5<=x<12 :
       wish="Good Morning"
    elif 12<=x<17:
     wish="Good Afternoon"
    elif 17<=x<24 :
     wish="Good evening"
    else  :
     wish="great"
    data={'date':Date,'time':Time,'day':Day,'wish':wish,'test':test}
    if request.method=='POST' :
        y=request.POST['ans']
        try:
                x=eval(y)
                x="Answer : "+str(x)
        except Exception as e:
            x=y
            x=x.lower()
            a.clear()
            if "add"  in x or "sum" in x or "plus"  in x:
               print("add")
               x=add(x)
            elif "into" in x or "multipl" in x or "product" in x:
               print("multiply")
               x=multiply(x)
            elif  "minus" in x or "sub" in x or "difference" in x:
              print("minus")
              x=minus(x)
            elif "divide" in x or "by" in x:
              print("divide")
              x=divide(x)
            else:
               x="sorry,i can get what r u saying"
        y="Question :"+y+" ?"
        data={'q':y,'d':x,'date':Date,'time':Time,'day':Day,'wish':wish,'test':test}
    s=render(request,'myapp/home.html',data)
    return s
