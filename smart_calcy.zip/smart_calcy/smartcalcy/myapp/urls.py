from myapp import views
from django.conf.urls import url

urlpatterns=[
    # url('^$',views.home1),
     url('home',views.home1),
     url('',views.home1),
]
