from django.db import models
from django.contrib.auth.models import User

class Ticket(models.Model):
    name=models.CharField(max_length=30)
    age=models.IntegerField()
    gender=models.CharField(max_length=30)
    aadhar_no=models.IntegerField()
    seat_type=models.CharField(max_length=30)
    seat_no=models.CharField(max_length=5)
    def __str__(self):
        return self.name
class stadiumuser(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE,parent_link=True)
    username=models.CharField(max_length=20,null=False)
